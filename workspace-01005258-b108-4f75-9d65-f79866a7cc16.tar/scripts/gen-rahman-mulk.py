#!/usr/bin/env python3
"""Generate Ar-Rahman and Al-Mulk surah files."""

AR_RAHMAN = [
    (55,1,"الرَّحْمَٰنُ","The Most Compassionate","اسم الله الرحمن الذي وسعت رحمته كل شيء."),
    (55,2,"عَلَّمَ الْقُرْآنَ","taught the Quran,","علّم عباده القرآن بإنزاله."),
    (55,3,"خَلَقَ الْإِنسَانَ","and created humanity,","خلق الإنسان من تراب."),
    (55,4,"عَلَّمَهُ الْبَيَانَ","and taught them speech.","علّمه البيان أي النطق والإفصاح."),
    (55,5,"الشَّمْسُ وَالْقَمَرُ بِحُسْبَانٍ","The sun and the moon travel with precision.","الشمس والقمر يجريان بحساب منظم لا يختل."),
    (55,6,"وَالنَّجْمُ وَالشَّجَرُ يَسْجُدَانِ","The stars and the trees all bow down in submission.","النجوم والشجر يسجدان لله طوعاً أو قهراً."),
    (55,7,"وَالسَّمَاءَ رَفَعَهَا وَوَضَعَ الْمِيزَانَ","As for the sky, He raised it high, and set the balance of justice,","رفع السماء ووضع الميزان للعدل بين الناس."),
    (55,8,"أَلَّا تَطْشَوْا فِي الْمِيزَانِ","so that you may not exceed your limits in the balance.","أمر بعدم الطغيان في الميزان."),
    (55,9,"وَأَقِيمُوا الْوَزْنَ بِالْقِسْطِ وَلَا تُخْسِرُوا الْمِيزَانَ","Maintain the balance with justice and do not fall short in it.","إقامة الوزن بالعدل وعدم النقص فيه."),
    (55,10,"وَالْأَرْضَ وَضَعَهَا لِلْأَنَامِ","And as for the earth, He set it up for all beings.","بسط الأرض للخلق لتستقر عليها."),
    (55,11,"فِيهَا فَاكِهَةٌ وَالنَّخْلُ ذَاتُ الْأَكْمَامِ","In it are fruits and date palms with sheaths,","في الأرض فواكه ونخل ذات أكمام (الطلع)."),
    (55,12,"وَالْحَبُّ ذُو الْعَصْفِ وَالرَّيْحَانُ","and grain with husk, and fragrant plants.","الحب الذي له قشر كالحنطة، والريحان الطيب."),
    (55,13,"فَبِأَيِّ آلَاءِ رَبِّكُمَا تُكَذِّبَانِ","So which of your Lord's marvellous bounties will you both deny?","تحدي للثقلين بكذب أي نعمة من نعم ربهم."),
    (55,14,"خَلَقَ الْإِنسَانَ مِن صَلْصَالٍ كَالْفَخَّارِ","He created humans from sounding clay like pottery,","خلق آدم من طين يابس له صوت كالفخار."),
    (55,15,"وَخَلَقَ الْجَانَّ مِن مَّارِجٍ مِّن نَّارٍ","and He created jinn from a smokeless flame of fire.","خلق الجن من طرف اللهب الناري الصافي."),
    (55,16,"فَبِأَيِّ آلَاءِ رَبِّكُمَا تُكَذِّبَانِ","So which of your Lord's marvellous bounties will you both deny?","تكرار التحدي بنعم الله."),
    (55,17,"رَبُّ الْمَشْرِقَيْنِ وَرَبُّ الْمَغْرِبَيْنِ","He is the Lord of the two sunrises and the Lord of the two sunsets.","رب المشرقين والمغربين للشمس والقمر أو للصيف والشتاء."),
    (55,18,"فَبِأَيِّ آلَاءِ رَبِّكُمَا تُكَذِّبَانِ","So which of your Lord's marvellous bounties will you both deny?","تكرار التحدي بنعم الله."),
    (55,19,"مَرَجَ الْبَحْرَيْنِ يَلْتَقِيَانِ","He merged the two bodies of water, letting them meet,","أرسل البحرين العذب والمالح يلتقيان."),
    (55,20,"بَيْنَهُمَا بَرْزَخٌ لَّا يَبْغِيَانِ","yet between them is a barrier they do not cross.","بين البحرين حاجز يمنع اختلاطهما."),
    (55,21,"فَبِأَيِّ آلَاءِ رَبِّكُمَا تُكَذِّبَانِ","So which of your Lord's marvellous bounties will you both deny?","تكرار التحدي بنعم الله."),
    (55,22,"يَخْرُجُ مِنْهُمَا اللُّؤْلُؤُ وَالْمَرْجَانُ","From both bodies of water emerge pearls and coral.","يخرج من البحرين اللؤلؤ والمرجان."),
    (55,23,"فَبِأَيِّ آلَاءِ رَبِّكُمَا تُكَذِّبَانِ","So which of your Lord's marvellous bounties will you both deny?","تكرار التحدي بنعم الله."),
    (55,24,"وَلَهُ الْجَوَارِ الْمُنشَآتُ فِي الْبَحْرِ كَالْأَعْلَامِ","And sailing through the sea are ships like mountains.","سخر الله السفن العظيمة تجري في البحر كالجبال."),
    (55,25,"فَبِأَيِّ آلَاءِ رَبِّكُمَا تُكَذِّبَانِ","So which of your Lord's marvellous bounties will you both deny?","تكرار التحدي بنعم الله."),
    (55,26,"كُلُّ مَنْ عَلَيْهَا فَانٍ","Everyone on earth will perish,","كل من على الأرض يموت."),
    (55,27,"وَيَبْقَىٰ وَجْهُ رَبِّكَ ذُو الْجَلَالِ وَالْإِكْرَامِ","but the Face of your Lord will remain, full of Majesty and Honour.","يبقى وجه الله الدال على ذاته الكاملة في الجلال والإكرام."),
    (55,28,"فَبِأَيِّ آلَاءِ رَبِّكُمَا تُكَذِّبَانِ","So which of your Lord's marvellous bounties will you both deny?","تكرار التحدي بنعم الله."),
    (55,29,"يَسْأَلُهُ مَن فِي السَّمَاوَاتِ وَالْأَرْضِ ۚ كُلَّ يَوْمٍ هُوَ فِي شَأْنٍ","All in the heavens and the earth beg Him for their needs daily; He is always engaged in some work.","كل أهل السماوات والأرض يسألون الله حوائجهم، وهو كل يوم في شأن."),
    (55,30,"فَبِأَيِّ آلَاءِ رَبِّكُمَا تُكَذِّبَانِ","So which of your Lord's marvellous bounties will you both deny?","تكرار التحدي بنعم الله."),
    (55,31,"سَنَفْرُغُ لَكُمْ أَيُّهَا الثَّقَلَانِ","We will soon attend to you both, O heavy beings humans and jinn!","سنفرغ لحسابكم أيها الثقلان من الإنس والجن."),
    (55,32,"فَبِأَيِّ آلَاءِ رَبِّكُمَا تُكَذِّبَانِ","So which of your Lord's marvellous bounties will you both deny?","تكرار التحدي بنعم الله."),
    (55,33,"يَا مَعْشَرَ الْجِنِّ وَالْإِنسِ إِنِ اسْتَطَعْتُمْ أَن تَنفُذُوا مِنْ أَقْطَارِ السَّمَاوَاتِ وَالْأَرْضِ فَانفُذُوا ۚ لَا تَنفُذُونَ إِلَّا بِسُلْطَانٍ","O assembly of jinn and humans! If you can cross the boundaries of the heavens and the earth, do so! But you cannot cross them except by Our authority.","تحدي للجن والإنس أن يفروا من أمر الله وأحكامه."),
    (55,34,"فَبِأَيِّ آلَاءِ رَبِّكُمَا تُكَذِّبَانِ","So which of your Lord's marvellous bounties will you both deny?","تكرار التحدي بنعم الله."),
    (55,35,"يُرْسَلُ عَلَيْكُمَا شُوَاظٌ مِّن نَّارٍ وَنُحَاسٌ فَلَا تَنتَصِرَانِ","A flare of fire and a flash of copper will be unleashed upon you both, and you will not be able to defend yourselves.","لو حاولتم الفرار لأُرسل عليكم لهب ونحاس فلا تنتصران."),
    (55,36,"فَبِأَيِّ آلَاءِ رَبِّكُمَا تُكَذِّبَانِ","So which of your Lord's marvellous bounties will you both deny?","تكرار التحدي بنعم الله."),
    (55,37,"فَإِذَا انشَقَّتِ السَّمَاءُ فَكَانَتْ وَرْدَةً كَالدِّهَانِ","When the sky splits apart, becoming as red as a rose, like stained leather,","يوم القيامة تنشق السماء وتتغير ألوانها كالوردة المدهونة."),
    (55,38,"فَبِأَيِّ آلَاءِ رَبِّكُمَا تُكَذِّبَانِ","So which of your Lord's marvellous bounties will you both deny?","تكرار التحدي بنعم الله."),
    (55,39,"فَيَوْمَئِذٍ لَّا يُسْأَلُ عَن ذَنبِهِ إِنسٌ وَلَا جَانٌّ","on that Day no human or jinn will be questioned about their sins.","يومئذ لا يُسألون عن ذنوبهم لأنهم يعرفون بسيماهم."),
    (55,40,"فَبِأَيِّ آلَاءِ رَبِّكُمَا تُكَذِّبَانِ","So which of your Lord's marvellous bounties will you both deny?","تكرار التحدي بنعم الله."),
    (55,41,"يُعْرَفُ الْمُجْرِمُونَ بِسِيمَاهُمْ فَيُؤْخَذُ بِالنَّوَاصِي وَالْأَقْدَامِ","The wicked will be recognized by their marks, and seized by their forelocks and feet.","المجرمون تُعرف صفحتهم فيُؤخذون بنواصيهم وأقدامهم إلى النار."),
    (55,42,"فَبِأَيِّ آلَاءِ رَبِّكُمَا تُكَذِّبَانِ","So which of your Lord's marvellous bounties will you both deny?","تكرار التحدي بنعم الله."),
    (55,43,"هَٰذِهِ جَهَنَّمُ الَّتِي يُكَذِّبُ بِهَا الْمُجْرِمُونَ","This is the Hell the wicked will deny!","تعرير المجرمين على جهنم التي كانوا يكذبون بها."),
    (55,44,"يَطُوفُونَ بَيْنَهَا وَبَيْنَ حَمِيمٍ آنٍ","They will circle between it and a boiling fountain.","يطوفون في النار وبين حميم شديد الحرارة."),
    (55,45,"فَبِأَيِّ آلَاءِ رَبِّكُمَا تُكَذِّبَانِ","So which of your Lord's marvellous bounties will you both deny?","تكرار التحدي بنعم الله."),
    (55,46,"وَلِمَنْ خَافَ مَقَامَ رَبِّهِ جَنَّتَانِ","But for those in awe of standing before their Lord, there will be two Gardens.","لمن خاف الوقوف بين يدي ربه يوم القيامة جنتان."),
    (55,47,"فَبِأَيِّ آلَاءِ رَبِّكُمَا تُكَذِّبَانِ","So which of your Lord's marvellous bounties will you both deny?","تكرار التحدي بنعم الله."),
    (55,48,"ذَوَاتَا أَفْنَانٍ","Both with an abundance of branches.","الجنتان ذواتا أغصان ناضرة بالثمار."),
    (55,49,"فَبِأَيِّ آلَاءِ رَبِّكُمَا تُكَذِّبَانِ","So which of your Lord's marvellous bounties will you both deny?","تكرار التحدي بنعم الله."),
    (55,50,"فِيهِمَا عَيْنَانِ تَجْرِيَانِ","In both are two flowing springs.","في كل جنة عينان تجريان."),
    (55,51,"فَبِأَيِّ آلَاءِ رَبِّكُمَا تُكَذِّبَانِ","So which of your Lord's marvellous bounties will you both deny?","تكرار التحدي بنعم الله."),
    (55,52,"فِيهِمَا مِن كُلِّ فَاكِهَةٍ زَوْجَانِ","In both are an abundance of fruits of every kind, in pairs.","في الجنتين من كل فاكهة صنفان."),
    (55,53,"فَبِأَيِّ آلَاءِ رَبِّكُمَا تُكَذِّبَانِ","So which of your Lord's marvellous bounties will you both deny?","تكرار التحدي بنعم الله."),
    (55,54,"مُتَّكِئِينَ عَلَىٰ فُرُشٍ بَطَائِنُهَا مِنْ إِسْتَبْرَقٍ ۚ وَجَنَى الْجَنَّتَيْنِ دَانٍ","They will be reclining on beds lined with rich brocade. And the fruit of both Gardens will hang within reach.","أهل الجنة متكئون على فرش مبطنة بإستبرق، وثمر الجنتين قريب التناول."),
    (55,55,"فَبِأَيِّ آلَاءِ رَبِّكُمَا تُكَذِّبَانِ","So which of your Lord's marvellous bounties will you both deny?","تكرار التحدي بنعم الله."),
    (55,56,"فِيهِنَّ قَاصِرَاتُ الطَّرْفِ لَمْ يَطْمِثْهُنَّ إِنسٌ قَبْلَهُمْ وَلَا جَانٌّ","There will be maidens with gorgeous eyes keeping only to their mates, whom no human or jinn has ever touched before.","في الجنة حور قاصرات الطرف لا ينظرن لغير أزواجهن، لم يطأهن أحد قبلهم."),
    (55,57,"فَبِأَيِّ آلَاءِ رَبِّكُمَا تُكَذِّبَانِ","So which of your Lord's marvellous bounties will you both deny?","تكرار التحدي بنعم الله."),
    (55,58,"كَأَنَّهُنَّ الْيَاقُوتُ وَالْمَرْجَانُ","They are like rubies and coral in beauty.","الحور كالياقوت في الصفاء والمرجان في الحمرة."),
    (55,59,"فَبِأَيِّ آلَاءِ رَبِّكُمَا تُكَذِّبَانِ","So which of your Lord's marvellous bounties will you both deny?","تكرار التحدي بنعم الله."),
    (55,60,"هَلْ جَزَاءُ الْإِحْسَانِ إِلَّا الْإِحْسَانُ","Is the reward of goodness anything but goodness?","هل جزاء من أحسن في الدنيا إلا الإحسان إليه في الآخرة."),
    (55,61,"فَبِأَيِّ آلَاءِ رَبِّكُمَا تُكَذِّبَانِ","So which of your Lord's marvellous bounties will you both deny?","تكرار التحدي بنعم الله."),
    (55,62,"وَمِن دُونِهِمَا جَنَّتَانِ","And below them in rank are two other Gardens.","إلى جانب الجنتين السابقتين جنتان أُخريان لأصحاب اليمين."),
    (55,63,"فَبِأَيِّ آلَاءِ رَبِّكُمَا تُكَذِّبَانِ","So which of your Lord's marvellous bounties will you both deny?","تكرار التحدي بنعم الله."),
    (55,64,"مُدْهَامَّتَانِ","both deep green in colour.","الجنتان مدهامتان خضراوان من شدة الري."),
    (55,65,"فَبِأَيِّ آلَاءِ رَبِّكُمَا تُكَذِّبَانِ","So which of your Lord's marvellous bounties will you both deny?","تكرار التحدي بنعم الله."),
    (55,66,"فِيهِمَا عَيْنَانِ نَضَّاخَتَانِ","In both are two flowing springs.","في الجنتين عينان فوارتان بالماء."),
    (55,67,"فَبِأَيِّ آلَاءِ رَبِّكُمَا تُكَذِّبَانِ","So which of your Lord's marvellous bounties will you both deny?","تكرار التحدي بنعم الله."),
    (55,68,"فِيهِمَا فَاكِهَةٌ وَنَخْلٌ وَرُمَّانٌ","In both are fruits, date palms, and pomegranates.","في الجنتين فاكهة ونخل ورمان."),
    (55,69,"فَبِأَيِّ آلَاءِ رَبِّكُمَا تُكَذِّبَانِ","So which of your Lord's marvellous bounties will you both deny?","تكرار التحدي بنعم الله."),
    (55,70,"فِيهِنَّ خَيْرَاتٌ حِسَانٌ","In both are maidens of excellent character and beauty.","في الجنتين نساء طيبات الأخلاق حسان الوجوه."),
    (55,71,"فَبِأَيِّ آلَاءِ رَبِّكُمَا تُكَذِّبَانِ","So which of your Lord's marvellous bounties will you both deny?","تكرار التحدي بنعم الله."),
    (55,72,"حُورٌ مَّقْصُورَاتٌ فِي الْخِيَامِ","Maidens secluded in pavilions.","حور محبوسات في خيام اللؤلؤ لا يخرجن منها."),
    (55,73,"فَبِأَيِّ آلَاءِ رَبِّكُمَا تُكَذِّبَانِ","So which of your Lord's marvellous bounties will you both deny?","تكرار التحدي بنعم الله."),
    (55,74,"لَمْ يَطْمِثْهُنَّ إِنسٌ قَبْلَهُمْ وَلَا جَانٌّ","Whom no human or jinn has ever touched before.","لم يطأهن أحد من الإنس أو الجن قبلاً."),
    (55,75,"فَبِأَيِّ آلَاءِ رَبِّكُمَا تُكَذِّبَانِ","So which of your Lord's marvellous bounties will you both deny?","تكرار التحدي بنعم الله."),
    (55,76,"مُتَّكِئِينَ عَلَىٰ رَفْرَفٍ خُضْرٍ وَعَبْقَرِيٍّ حِسَانٍ","They will be reclining on green cushions and fine carpets.","أهل الجنة متكئون على وسائد خضر وفرش حسان."),
    (55,77,"تَبَارَكَ اسْمُ رَبِّكَ ذِي الْجَلَالِ وَالْإِكْرَامِ","Blessed is the Name of your Lord, full of Majesty and Honour.","تعظيم لاسم الله المبارك ذي الجلال في عظمته والإكرام لخلقه."),
    (55,78,"تَبَارَكَ اسْمُ رَبِّكَ ذِي الْجَلَالِ وَالْإِكْرَامِ","Blessed is the Name of your Lord, full of Majesty and Honour.","ختام السورة بتعظيم اسم الله."),
]

AL_MULK = [
    (67,1,"تَبَارَكَ الَّذِي بِيَدِهِ الْمُلْكُ وَهُوَ عَلَىٰ كُلِّ شَيْءٍ قَدِيرٌ","Blessed is the One in Whose Hands rests all authority. And He is Most Capable of everything.","تنزيه الله وتعظيمه، المالك لكل شيء، القادر على كل شيء."),
    (67,2,"الَّذِي خَلَقَ الْمَوْتَ وَالْحَيَاةَ لِيَبْلُوَكُمْ أَيُّكُمْ أَحْسَنُ عَمَلًا ۚ وَهُوَ الْعَزِيزُ الْغَفُورُ","He is the One Who created death and life in order to test which of you is best in deeds. And He is the Almighty, All-Forgiving.","خلق الله الموت والحياة ليختبر عباده فيعملوا الصالحات، وهو العزيز الغفور."),
    (67,3,"الَّذِي خَلَقَ سَبْعَ سَمَاوَاتٍ طِبَاقًا ۖ مَّا تَرَىٰ فِي خَلْقِ الرَّحْمَٰنِ مِن تَفَاوُتٍ ۖ فَارْجِعِ الْبَصَرَ هَلْ تَرَىٰ مِن فُطُورٍ","He is the One Who created seven heavens, one above the other. You will never see any imperfection in the creation of the Most Compassionate. So look again: do you see any flaws?","خلق سبع سماوات طباقاً بلا تفاوت ولا اختلال."),
    (67,4,"ثُمَّ ارْجِعِ الْبَصَرَ كَرَّتَيْنِ يَنقَلِبْ إِلَيْكَ الْبَصَرُ خَاسِئًا وَهُوَ حَسِيرٌ","Then look again and again—your sight will return frustrated and weary.","كر البصر فلا يرى عيباً، يرجع صاغراً حسيراً."),
    (67,5,"وَلَقَدْ زَيَّنَّا السَّمَاءَ الدُّنْيَا بِمَصَابِيحَ وَجَعَلْنَاهَا رُجُومًا لِّلشَّيَاطِينِ ۖ وَأَعْتَدْنَا لَهُمْ عَذَابَ السَّعِيرِ","Indeed, We adorned the lowest heaven with lamps stars and made them a source of missiles to drive away invisible devils, for whom We have also prepared a torment of the Blaze.","زيّن الله السماء بالنجوم، وجعلها رجوماً للشياطين، وأعد لهم عذاب السعير."),
    (67,6,"وَلِلَّذِينَ كَفَرُوا بِرَبِّهِمْ عَذَابُ جَهَنَّمَ ۚ وَبِئْسَ الْمَصِيرُ","For those who reject their Lord, there is the torment of Hell. What an evil destination!","للكافرين عذاب جهنم، وبئس المصير."),
    (67,7,"إِذَا أُلْقُوا فِيهَا سَمِعُوا لَهَا شَهِيقًا وَهِيَ تَفُورُ","When they are tossed into it, they will hear its roaring as it boils over,","إذا أُلقوا في جهنم سمعوا لها صوتاً منكراً وهي تغلي بهم."),
    (67,8,"تَكَادُ تَمَيَّزُ مِنَ الْغَيْظِ ۖ كُلَّمَا أُلْقِيَ فِيهَا فَوْجٌ سَأَلَهُمْ خَزَنَتُهَا أَلَمْ يَأْتِكُمْ نَذِيرٌ","almost bursting in fury. Every time a group is cast into it, its keepers will ask them scornfully: Did a warner not come to you?","تكاد جهنم تتقطع من الغيظ، والخزنة تسأل: ألم يأتكم نذير؟"),
    (67,9,"قَالُوا بَلَىٰ قَدْ جَاءَنَا نَذِيرٌ فَكَذَّبْنَا وَقُلْنَا مَا نَزَّلَ اللَّهُ مِن شَيْءٍ إِنْ أَنتُمْ إِلَّا فِي ضَلَالٍ كَبِيرٍ","They will reply: Yes, a warner did come to us, but we rejected him and said: Allah has revealed nothing. You are solely lost in great error.","اعتراف الكفار بمجيء النذير وكذبهم به."),
    (67,10,"وَقَالُوا لَوْ كُنَّا نَسْمَعُ أَوْ نَعْقِلُ مَا كُنَّا فِي أَصْحَابِ السَّعِيرِ","And they will further say: If only we had listened or reasoned, we would not be among the residents of the Blaze.","ندم الكفار يوم القيامة على عدم سماعهم وعقلهم."),
    (67,11,"فَاعْتَرَفُوا بِذَنبِهِمْ فَسُحْقًا لِّأَصْحَابِ السَّعِيرِ","Then they will confess their sin. So away with the residents of the Blaze!","اعترفوا بذنبهم فبعداً لأهل السعير."),
    (67,12,"إِنَّ الَّذِينَ يَخْشَوْنَ رَبَّهُم بِالْغَيْبِ لَهُم مَّغْفِرَةٌ وَأَجْرٌ كَبِيرٌ","Indeed, those who fear their Lord without seeing Him will have forgiveness and a great reward.","للذين يخشون الله في الغيب مغفرة وأجر عظيم."),
    (67,13,"وَأَسِرُّوا قَوْلَكُمْ أَوِ اجْهُرُوا بِهِ ۖ إِنَّهُ عَلِيمٌ بِذَاتِ الصُّدُورِ","Whether you conceal your words or declare them, He surely knows best what is hidden in everyone's heart.","سواء أسررتم القول أو جهرتم به، فالله عليم بما في الصدور."),
    (67,14,"أَلَا يَعْلَمُ مَنْ خَلَقَ وَهُوَ اللَّطِيفُ الْخَبِيرُ","Should He not know—He Who created? And He is the Subtle, the All-Aware.","كيف لا يعلم خالق الأشياء وهو اللطيف الخبير بها؟"),
    (67,15,"هُوَ الَّذِي جَعَلَ لَكُمُ الْأَرْضَ ذَلُولًا فَامْشُوا فِي مَنَاكِبِهَا وَكُلُوا مِن رِّزْقِهِ ۖ وَإِلَيْهِ النُّشُورُ","He is the One Who smoothed out the earth for you, so move about in its regions, eat from His provisions, and to Him is the resurrection of all.","سخر الله الأرض للسير فيها والأكل من رزقها، وإليه البعث."),
    (67,16,"أَأَمِنتُم مَّن فِي السَّمَاءِ أَن يَخْسِفَ بِكُمُ الْأَرْضَ فَإِذَا هِيَ تَمُورُ","Are you pagans not afraid that the One in heaven may cause the earth to swallow you up? Then suddenly it would rock back and forth in an earthquake.","أمنتم من استوى على العرش أن يخسف بكم الأرض فتمور بكم؟"),
    (67,17,"أَمْ أَمِنتُم مَّن فِي السَّمَاءِ أَن يُرْسِلَ عَلَيْكُمْ حَاصِبًا ۖ فَسَتَعْلَمُونَ كَيْفَ نَذِيرِ","Or are you not afraid that the One in heaven may unleash upon you a storm of stones. Only then will you realize how true My warning was!","أمنتم أن يرسل الله عليكم حاصباً (ريحاً بحصى) فستعلمون كيف نذير."),
    (67,18,"وَلَقَدْ كَذَّبَ الَّذِينَ مِن قَبْلِهِمْ فَكَيْفَ كَانَ نَكِيرِ","Indeed, many of those nations before them rejected their messengers, so how severe was My denial of them!","كذب الأمم السابقة رسلها فكيف كان إنكاري عليهم بالعذاب!"),
    (67,19,"أَوَلَمْ يَرَوْا إِلَى الطَّيْرِ فَوْقَهُمْ صَافَّاتٍ وَيَقْبِضْنَ ۚ مَا يُمْسِكُهُنَّ إِلَّا الرَّحْمَٰنُ ۚ إِنَّهُ بِكُلِّ شَيْءٍ بَصِيرٌ","Have they not seen the birds above them, spreading and folding their wings? None holds them up except the Most Compassionate. Indeed, He is All-Seeing of everything.","الاستدلال بتسخير الطير في الجو على قدرة الله."),
    (67,20,"أَمَّنْ هَٰذَا الَّذِي هُوَ جُندٌ لَّكُمْ يَنصُرُكُم مِّن دُونِ الرَّحْمَٰنِ ۚ إِنِ الْكَافِرُونَ إِلَّا فِي غُرُورٍ","Or who is this that would be an army for you to protect you except the Most Compassionate? The disbelievers are truly lost in delusion.","من ذا الذي يجند جنداً ينصركم من دون الله؟ الكافرون في غرور."),
    (67,21,"أَمَّنْ هَٰذَا الَّذِي يَرْزُقُكُمْ إِنْ أَمْسَكَ رِزْقَهُ ۚ بَل لَّجُّوا فِي عُتُوٍّ وَنُفُورٍ","Or who is this that would provide you with sustenance if He were to withhold His provision? In fact, they persist in arrogance and avoidance.","من يرزقكم إن منع الله رزقه؟ بل استمروا في طغيان ونفور."),
    (67,22,"أَفَمَن يَمْشِي مُكِبًّا عَلَىٰ وَجْهِهِ أَهْدَىٰ أَمَّن يَمْشِي سَوِيًّا عَلَىٰ صِرَاطٍ مُّسْتَقِيمٍ","Is the one who walks humbly falling on his face better guided than the one who walks upright on the Straight Path?","مثل الكافر كمن يمشي منكساً على وجهه، والمؤمن كمن يمشي معتدلاً على صراط مستقيم."),
    (67,23,"قُلْ هُوَ الَّذِي أَنشَأَكُمْ وَجَعَلَ لَكُمُ السَّمْعَ وَالْأَبْصَارَ وَالْأَفْئِدَةَ ۖ قَلِيلًا مَّا تَشْكُرُونَ","Say, O Prophet: He is the One Who brought you into being and gave you hearing, sight, and intellect. Yet you hardly give any thanks.","الله الذي خلقكم ووهبكم السمع والبصر والفؤاد، قليلاً ما تشكرون."),
    (67,24,"قُلْ هُوَ الَّذِي ذَرَأَكُمْ فِي الْأَرْضِ وَإِلَيْهِ تُحْشَرُونَ","Say: He is the One Who scattered you all across the earth, and to Him you will all be gathered.","الله الذي نشركم في الأرض، وإليه يحشركم."),
    (67,25,"وَيَقُولُونَ مَتَىٰ هَٰذَا الْوَعْدُ إِن كُنتُمْ صَادِقِينَ","They argue: When will this threat come to pass, if what you say is true?","استعجال المشركين للعذاب استبعاداً له."),
    (67,26,"قُلْ إِنَّمَا الْعِلْمُ عِندَ اللَّهِ وَإِنَّمَا أَنَا نَذِيرٌ مُّبِينٌ","Say, O Prophet: That knowledge is only with Allah, and I am only sent to give you clear warnings.","العلم بوقوع العذاب عند الله، والنبي نذير مبين."),
    (67,27,"فَلَمَّا رَأَوْهُ زُلْفَةً سِيئَتْ وُجُوهُ الَّذِينَ كَفَرُوا وَقِيلَ هَٰذَا الَّذِي كُنتُم بِهِ تَدَّعُونَ","When they finally see the torment approaching, the faces of the disbelievers will be miserable. And it will be said: This is what you were calling for!","لما رأوا العذاب قريباً ساءت وجوههم، وقيل: هذا الذي كنتم تستعجلون."),
    (67,28,"قُلْ أَرَأَيْتُمْ إِنْ أَهْلَكَنِيَ اللَّهُ وَمَن مَّعِيَ أَوْ رَحِمَنَا فَمَن يُجِيرُ الْكَافِرِينَ مِنْ عَذَابٍ أَلِيمٍ","Say: Consider: whether He destroys me and those with me, or has mercy on us, who will protect the disbelievers from a painful torment?","سواء أهلكنا الله أو رحمنا، فمن يحمي الكافرين من العذاب؟"),
    (67,29,"قُلْ هُوَ الرَّحْمَٰنُ آمَنَّا بِهِ وَعَلَيْهِ تَوَكَّلْنَا ۖ فَسَتَعْلَمُونَ مَنْ هُوَ فِي ضَلَالٍ مُّبِينٍ","Say: He is the Most Compassionate. We have believed in Him, and in Him we trust. Soon you all will know who is clearly astray.","نحن آمنا بالرحمن وتوكلنا عليه، فستعلمون من هو في ضلال."),
    (67,30,"قُلْ أَرَأَيْتُمْ إِنْ أَصْبَحَ مَاؤُكُمْ غَوْرًا فَمَن يَأْتِيكُم بِمَاءٍ مَّعِينٍ","Say: Consider: if your water were to sink into the earth, then who else could bring you flowing water?","لو غاض ماؤكم في الأرض فمن يأتيكم بماء معين؟ توحيد الله وبيان قدرته."),
]


def escape_value(s):
    out = []
    is_left = True
    for ch in s:
        if ch == '"':
            out.append('\u201C' if is_left else '\u201D')
            is_left = not is_left
        elif ch == '\\':
            out.append('\\\\')
        else:
            out.append(ch)
    return ''.join(out)


def write_file(path, name, data):
    lines = [
        f"// Surah {data[0][0]} - {len(data)} verses (auto-generated)",
        "import type { VerseText } from \"./verses\";",
        "",
        f"const {name}: VerseText[] = [",
    ]
    for surah, verse, arabic, trans, tafsir in data:
        a = escape_value(arabic)
        t = escape_value(trans)
        f_ = escape_value(tafsir)
        lines.append(f'  {{ surahNumber: {surah}, verseNumber: {verse}, arabic: "{a}", translation: "{t}", tafsir: "{f_}" }},')
    lines.append("];")
    lines.append("")
    lines.append(f"export const {name.upper()}_VERSES = {name};")
    lines.append("")
    with open(path, 'w', encoding='utf-8') as fp:
        fp.write('\n'.join(lines))
    print(f"Wrote {path} ({len(data)} verses)")


base = "/home/z/my-project/src/lib/quran"
write_file(f"{base}/surah-ar-rahman.ts", "arRahman", AR_RAHMAN)
write_file(f"{base}/surah-al-mulk.ts", "alMulk", AL_MULK)
