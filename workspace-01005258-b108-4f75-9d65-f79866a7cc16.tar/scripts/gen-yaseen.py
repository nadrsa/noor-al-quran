#!/usr/bin/env python3
"""Generate clean Quran surah files with proper quote escaping."""
import os
import json

# Surah data: each tuple is (surah, verse, arabic, translation, tafsir)
# Inner double quotes in any field will be auto-converted to Unicode smart quotes.

YASEEN = [
    (36,1,"يسٓ","Yã-Sĩn.","حروف مقطعة في فاتحة السورة، من أسرار القرآن التي استأثر الله بعلمها."),
    (36,2,"وَالْقُرْآنِ الْحَكِيمِ","By the Quran, rich in wisdom!","قسم بالقرآن الحكيم المحكم الذي لا يأتيه الباطل."),
    (36,3,"إِنَّكَ لَمِنَ الْمُرْسَلِينَ","You are truly one of the messengers,","إثبات النبوة للرسول صلى الله عليه وسلم."),
    (36,4,"عَلَىٰ صِرَاطٍ مُّسْتَقِيمٍ","upon the Straight Path.","على طريق مستقيم لا اعوجاج فيه."),
    (36,5,"تَنزِيلَ الْعَزِيزِ الرَّحِيمِ","A revelation from the Almighty, Most Merciful,","هذا القرآن منزل من الله العزيز في ملكه الرحيم بخلقه."),
    (36,6,"لِتُنذِرَ قَوْمًا مَّا أُنذِرَ آبَاؤُهُمْ فَهُمْ غَافِلُونَ","so that you may warn a people whose ancestors were not warned, and so are heedless.","لتنذر العرب وهم أميون لم يُنذر آباؤهم من قبل."),
    (36,7,"لَقَدْ حَقَّ الْقَوْلُ عَلَىٰ أَكْثَرِهِمْ فَهُمْ لَا يُؤْمِنُونَ","Indeed, the decree of torment has overtaken most of them, for they do not believe.","سبق العلم الإلهي بأن أكثرهم لا يؤمنون."),
    (36,8,"إِنَّا جَعَلْنَا فِي أَعْنَاقِهِمْ أَغْلَالًا فَهِيَ إِلَى الْأَذْقَانِ فَهُم مُّقْمَحُونَ","It is We who have placed collars around their necks up to their chins so their heads are forced up.","مثل لكونهم ممنوعين من الإيمان كمن غُلّت يداه إلى عنقه فرفع رأسه."),
    (36,9,"وَجَعَلْنَا مِن بَيْنِ أَيْدِيهِمْ سَدًّا وَمِنْ خَلْفِهِمْ سَدًّا فَأَغْشَيْنَاهُمْ فَهُمْ لَا يُبْصِرُونَ","And We have placed a barrier before and behind them, covering them so they fail to see.","تمثيل لإعراضهم عن الإيمان فصاروا كالمسدود عنهم."),
    (36,10,"وَسَوَاءٌ عَلَيْهِمْ أَأَنذَرْتَهُمْ أَمْ لَمْ تُنذِرْهُمْ لَا يُؤْمِنُونَ","It is the same whether you warn them or not: they will not believe.","استغرقهم الشقاء فلا ينفعهم الإنذار."),
    (36,11,"إِنَّمَا تُنذِرُ مَنِ اتَّبَعَ الذِّكْرَ وَخَشَى الرَّحْمَٰنَ بِالْغَيْبِ ۖ فَبَشِّرْهُ بِمَغْفِرَةٍ وَأَجْرٍ كَرِيمٍ","You can only warn whoever follows this Quran and fears the Most Compassionate without seeing Him. So give them good news of forgiveness and a noble reward.","نافع إنذارك لمن اتبع القرآن وخشي الله في الغيب."),
    (36,12,"إِنَّا نَحْنُ نُحْيِي الْمَوْتَىٰ وَنَكْتُبُ مَا قَدَّمُوا وَآثَارَهُمْ ۚ وَكُلَّ شَيْءٍ أَحْصَيْنَاهُ فِي إِمَامٍ مُّبِينٍ","Surely We alone bring the dead back to life and record what deeds they send ahead and leave behind. Everything is kept in an evident Record.","إثبات البعث، وأن الله يكتب أعمال العباد وأثرهم في الدنيا."),
    (36,13,"وَاضْرِبْ لَهُم مَّثَلًا أَصْحَابَ الْقَرْيَةِ إِذْ جَاءَهَا الْمُرْسَلُونَ","Compare them to the people of a town to whom messengers came,","ضرب مثل لمكة بما جرى لأهل أنطاكية مع رسل عيسى."),
    (36,14,"إِذْ أَرْسَلْنَا إِلَيْهِمُ اثْنَيْنِ فَكَذَّبُوهُمَا فَعَزَّزْنَا بِثَالِثٍ فَقَالُوا إِنَّا إِلَيْكُم مُّرْسَلُونَ","We sent them two messengers, but they rejected both. So We reinforced them with a third. They declared: We have indeed been sent to you.","قصة أصحاب القرية الذين أُرسل إليهم رسلان فكذبوهما، فأيدوا بثالث."),
    (36,15,"قَالُوا مَا أَنتُمْ إِلَّا بَشَرٌ مِّثْلُنَا وَمَا أَنزَلَ الرَّحْمَٰنُ مِن شَيْءٍ إِنْ أَنتُمْ إِلَّا تَكْذِبُونَ","They replied: You are only humans like us! The Most Compassionate has revealed nothing. You are only lying.","جحد أهل القرية نبوة الرسل بحجة أنهم بشر."),
    (36,16,"قَالُوا رَبُّنَا يَعْلَمُ إِنَّا إِلَيْكُمْ لَمُرْسَلُونَ","They responded: Our Lord knows that we have indeed been sent to you.","أقسم الرسل أنهم مرسلون، وعلم الله يشهد بذلك."),
    (36,17,"وَمَا عَلَيْنَا إِلَّا الْبَلَاغُ الْمُبِينُ","Our duty is only to deliver the message clearly.","ليس علينا إلا البلاغ، والهداية بيد الله."),
    (36,18,"قَالُوا إِنَّا تَطَيَّرْنَا بِكُمْ ۖ لَئِن لَّمْ تَنتَهُوا لَنَرْجُمَنَّكُمْ وَلَيَمَسَّنَّكُم مِّنَّا عَذَابٌ أَلِيمٌ","They replied: We consider you a bad omen. If you do not stop, we will surely stone you to death, and you will suffer a painful punishment from us.","تشاؤم أهل القرية بالرسل وتهديدهم بالرجم."),
    (36,19,"قَالُوا طَائِرُكُم مَّعَكُمْ ۚ أَئِن ذُكِّرْتُم ۚ بَلْ أَنتُمْ قَوْمٌ مُّسْرِفُونَ","The messengers said: Your bad omen lies within yourselves. Are you saying this because you were reminded of the truth? No! You are a transgressing people.","الرسل يبينون أن الشؤم من أعمالهم لا من الرسل."),
    (36,20,"وَجَاءَ مِنْ أَقْصَى الْمَدِينَةِ رَجُلٌ يَسْعَىٰ قَالَ يَا قَوْمِ اتَّبِعُوا الْمُرْسَلِينَ","Then a man came running from the farthest part of the city, crying: My people! Follow the messengers.","مجيء حبيب النجار مؤمناً من أقصى المدينة يدعو قومه لاتباع الرسل."),
    (36,21,"اتَّبِعُوا مَن لَّا يَسْأَلُكُمْ أَجْرًا وَهُم مُّهْتَدُونَ","Follow those who ask no reward of you, and are rightly guided.","وصف الرسل بأنهم لا يطلبون أجراً وعلى هدى."),
    (36,22,"وَمَا لِيَ لَا أَعْبُدُ الَّذِي فَطَرَنِي وَإِلَيْهِ تُرْجَعُونَ","It would not be right for me not to worship the One Who created me, and to Whom you will all be returned.","الحجة أن الله هو الخالق وإليه المرجع فحقه العبادة."),
    (36,23,"أَأَتَّخِذُ مِن دُونِهِ آلِهَةً إِن يُرِدْنِ الرَّحْمَٰنُ بِضُرٍّ لَّا تُغْنِ عَنِّي شَفَاعَتُهُمْ شَيْئًا وَلَا يُنقِذُونَ","How could I take other gods instead of Him? If the Most Compassionate intended to harm me, their intercession would be of no use whatsoever, nor could they save me.","بطلان عبادة غير الله لأنها لا تنفع ولا تضر."),
    (36,24,"إِنِّي إِذًا لَّفِي ضَلَالٍ مُّبِينٍ","In that case I would truly be in clear error.","لو عبدت غير الله لكنت في ضلال واضح."),
    (36,25,"إِنِّي آمَنتُ بِرَبِّكُمْ فَاسْمَعُونِ","Indeed, I believe in your Lord, so listen to me.","إيمان حبيب النجار وجهاره بالحق."),
    (36,26,"قِيلَ ادْخُلِ الْجَنَّةَ ۖ قَالَ يَا لَيْتَ قَوْمِي يَعْلَمُونَ","He was told: Enter Paradise! He said: If only my people knew…","كرامة الله لمؤمن آل يس بدخوله الجنة، وتمنيه علم قومه بما هو فيه من النعيم."),
    (36,27,"بِمَا غَفَرَ لِي رَبِّي وَجَعَلَنِي مِنَ الْمُكْرَمِينَ","how my Lord has forgiven me, and made me one of the honourable ones!","سبب تمنيه: شكراً لله على مغفرته وإكرامه."),
    (36,28,"وَمَا أَنزَلْنَا عَلَىٰ قَوْمِهِ مِن بَعْدِهِ مِن جُندٍ مِّنَ السَّمَاءِ وَمَا كُنَّا مُنزِلِينَ","We did not send any soldiers from heaven against his people after his death, nor do We need to send any.","ما احتاج الله إلى جند من السماء لإهلاك قومه."),
    (36,29,"إِن كَانَتْ إِلَّا صَيْحَةً وَاحِدَةً فَإِذَا هُمْ خَامِدُونَ","It only took one Blast, and then they were silent.","أهلكوا بصيحة واحدة فماتوا جميعاً."),
    (36,30,"يَا حَسْرَةً عَلَى الْعِبَادِ ۚ مَا يَأْتِيهِم مِّن رَّسُولٍ إِلَّا كَانُوا بِهِ يَسْتَهْزِئُونَ","Alas for wrongdoing servants! No messenger ever came to them without being mocked.","تحسر على العباد لاستهزائهم بالرسل."),
    (36,31,"أَلَمْ يَرَوْا كَمْ أَهْلَكْنَا قَبْلَهُم مِّنَ الْقُرُونِ أَنَّهُمْ إِلَيْهِمْ لَا يَرْجِعُونَ","Do they not see how many generations We destroyed before them, who will never return to them?","تذكير بإهلاك الأمم السابقة وعدم رجوعها."),
    (36,32,"وَإِن كُلٌّ لَّمَّا جَمِيعٌ لَّدَيْنَا مُحْضَرُونَ","But each and every one of them will be brought before Us.","جميع الأمم محشورة إلى الله للحساب."),
    (36,33,"وَآيَةٌ لَّهُمُ الْأَرْضُ الْمَيْتَةُ أَحْيَيْنَاهَا وَأَخْرَجْنَا مِنْهَا حَبًّا فَمِنْهُ يَأْكُلُونَ","A sign for them is the dead earth: We bring it back to life, producing grain from which they eat.","الاستدلال على البعث بإحياء الأرض الميتة."),
    (36,34,"وَجَعَلْنَا فِيهَا جَنَّاتٍ مِّن نَّخِيلٍ وَأَعْنَابٍ وَفَجَّرْنَا فِيهَا مِنَ الْعُيُونِ","We place in it gardens of palm trees and grapevines, and cause springs to gush forth,","نعمة الله في خلق الجنات والعيون."),
    (36,35,"لِيَأْكُلُوا مِن ثَمَرِهِۦ وَمَا عَمِلَتْهُ أَيْدِيهِمْ ۖ أَفَلَا يَشْكُرُونَ","so that they may eat from its fruit, which their own hands did not produce. Will they not then give thanks?","التذكير بنعمة الأكل من ثمار لم يتعبوا فيها."),
    (36,36,"سُبْحَانَ الَّذِي خَلَقَ الْأَزْوَاجَ كُلَّهَا مِمَّا تُنبِتُ الْأَرْضُ وَمِنْ أَنفُسِهِمْ وَمِمَّا لَا يَعْلَمُونَ","Glory be to the One Who created all things in pairs—be it what the earth produces, their own kind, or what they do not know.","تنزيه الله على خلق الأزواج في النبات والحيوان وغيرها."),
    (36,37,"وَآيَةٌ لَّهُمُ اللَّيْلُ نَسْلَخُ مِنْهُ النَّهَارَ فَإِذَا هُم مُّظْلِمُونَ","Another sign for them is the night: We strip daylight from it, leaving them in darkness.","آية في تعاقب الليل والنهار."),
    (36,38,"وَالشَّمْسُ تَجْرِي لِمُسْتَقَرٍّ لَّهَا ۚ ذَٰلِكَ تَقْدِيرُ الْعَزِيزِ الْعَلِيمِ","The sun travels toward its destination. Such is the design of the Almighty, the All-Knowing.","آية في جريان الشمس لمستقرها بتقدير الله."),
    (36,39,"وَالْقَمَرَ قَدَّرْنَاهُ مَنَازِلَ حَتَّىٰ عَادَ كَالْعُرْجُونِ الْقَدِيمِ","And the moon—We have determined its phases, until it returns to its initial state, like an old, curved date stalk.","آية في منازل القمر حتى يصير كالعذق القديم."),
    (36,40,"لَا الشَّمْسُ يَنبَغِي لَهَا أَن تُدْرِكَ الْقَمَرَ وَلَا اللَّيْلُ سَابِقُ النَّهَارِ ۚ وَكُلٌّ فِي فَلَكٍ يَسْبَحُونَ","It is not for the sun to catch up with the moon, nor does the night outstrip the day. Each is travelling in an orbit of their own.","لكل من الشمس والقمر والكواكب فلكها الذي تجري فيه."),
    (36,41,"وَآيَةٌ لَّهُمْ أَنَّا حَمَلْنَا ذُرِّيَّتَهُمْ فِي الْفُلْكِ الْمَشْحُونِ","It is a sign for them that We carried their descendants with Noah in the fully loaded Ark,","آية في حمل ذرية آدم في سفينة نوح."),
    (36,42,"وَخَلَقْنَا لَهُم مِّن مِّثْلِهِ مَا يَرْكَبُونَ","and created for them things similar to ride.","خلق الله للناس من المراكب مثل سفينة نوح."),
    (36,43,"وَإِن نَّشَأْ نُغْرِقْهُمْ فَلَا صَرِيخَ لَهُمْ وَلَا هُمْ يُنقَذُونَ","If We willed, We could drown them: there would be no response to their cries, nor would they be saved,","قدرة الله على إغراقهم لو شاء."),
    (36,44,"إِلَّا رَحْمَةً مِّنَّا وَمَتَاعًا إِلَىٰ حِينٍ","except by mercy from Us and as a provision for a while.","إلا رحمة من الله بقاءً إلى انقضاء الآجال."),
    (36,45,"وَإِذَا قِيلَ لَهُمُ اتَّقُوا مَا بَيْنَ أَيْدِيكُمْ وَمَا خَلْفَكُمْ لَعَلَّكُمْ تُرْحَمُونَ","When it is said to them: Beware of what is ahead of you and what is behind you, so you may be given mercy, they turn away.","أمر المشركين بالتقوى في الدنيا والآخرة لينالوا الرحمة."),
    (36,46,"وَمَا تَأْتِيهِم مِّنْ آيَةٍ مِّنْ آيَاتِ رَبِّهِمْ إِلَّا كَانُوا عَنْهَا مُعْرِضِينَ","Whenever a sign comes to them from their Lord, they turn away from it.","إعراضهم عن كل آية تأتيهم."),
    (36,47,"وَإِذَا قِيلَ لَهُمْ أَنفِقُوا مِمَّا رَزَقَكُمُ اللَّهُ قَالَ الَّذِينَ كَفَرُوا لِلَّذِينَ آمَنُوا أَنُطْعِمُ مَن لَّوْ يَشَاءُ اللَّهُ أَطْعَمَهُ إِنْ أَنتُمْ إِلَّا فِي ضَلَالٍ مُّبِينٍ","And when it is said to them: Donate from what Allah has provided for you, the disbelievers say to the believers: Why should we feed those whom Allah could have fed if He wanted to? You are clearly astray!","امتنان الكفار عن الإطعام بزعم أن الله يرزق من يشاء."),
    (36,48,"وَيَقُولُونَ مَتَىٰ هَٰذَا الْوَعْدُ إِن كُنتُمْ صَادِقِينَ","And they ask the believers: When will this promise be fulfilled, if what you say is true?","استعجال المشركين للبعث استبعاداً له."),
    (36,49,"مَا يَنظُرُونَ إِلَّا صَيْحَةً وَاحِدَةً تَأْخُذُهُمْ وَهُمْ يَخِصِّمُونَ","They only wait for a single Blast, which will seize them while they are disputing.","ما ينتظرون إلا نفخة الصور تأخذهم وهم يتخاصمون في أسواقهم."),
    (36,50,"فَلَا يَسْتَطِيعُونَ تَوْصِيَةً وَلَا إِلَىٰ أَهْلِهِمْ يَرْجِعُونَ","They will not be able to make a bequest, nor return to their families.","سرعة البعث وأنهم يُبغتون فلا يوصون ولا يرجعون."),
    (36,51,"وَنُفِخَ فِي الصُّورِ فَإِذَا هُم مِّنَ الْأَجْدَاثِ إِلَىٰ رَبِّهِمْ يَنسِلُونَ","The Trumpet will be blown, and then—behold!—they will all rush from their graves to their Lord.","النفخة الثانية يقوم الناس من القبور إلى ربهم."),
    (36,52,"قَالُوا يَا وَيْلَنَا مَن بَعَثَنَا مِن مَّرْقَدِنَا ۜ هَٰذَا مَا وَعَدَ الرَّحْمَٰنُ وَصَدَقَ الْمُرْسَلُونَ","They will cry: Oh, woe to us! Who has raised us from our place of sleep? The response will be: This is what the Most Compassionate had promised, and the messengers told the truth.","قول الكفار عند البعث وتذكيرهم بما وعدهم به الرسل."),
    (36,53,"إِن كَانَتْ إِلَّا صَيْحَةً وَاحِدَةً فَإِذَا هُمْ جَمِيعٌ لَّدَيْنَا مُحْضَرُونَ","It will only take one Blast, and then they will all be brought before Us.","سهولة البعث، صيحة واحدة فيحشرون."),
    (36,54,"فَالْيَوْمَ لَا تُظْلَمُ نَفْسٌ شَيْئًا وَلَا تُجْزَوْنَ إِلَّا مَا كُنتُمْ تَعْمَلُونَ","Today no soul will be wronged in the least, and you will only be rewarded for what you used to do.","عدل الله يوم القيامة لا يُظلم أحد ولا يُجازى إلا بعمله."),
    (36,55,"إِنَّ أَصْحَابَ الْجَنَّةِ الْيَوْمَ فِي شُغُلٍ فَاكِهُونَ","Surely the residents of Paradise will be fully occupied with bliss today.","حال أهل الجنة في النعيم والفرح."),
    (36,56,"هُمْ وَأَزْوَاجُهُمْ فِي ظِلَالٍ عَلَى الْأَرَائِكِ مُتَّكِئُونَ","They and their spouses will be in cool shade, reclining on canopied couches.","تنعمهم مع أزواجهم في ظلال الجنة."),
    (36,57,"لَهُمْ فِيهَا فَاكِهَةٌ وَلَهُم مَّا يَدَّعُونَ","There they will have fruits and whatever they desire,","لهم في الجنة فاكهة وكل ما يطلبون."),
    (36,58,"سَلَامٌ قَوْلًا مِّن رَّبٍّ رَّحِيمٍ","and they will be greeted with: Peace, a word from a Lord Most Merciful.","تحية الله لأهل الجنة بالسلام."),
    (36,59,"وَامْتَازُوا الْيَوْمَ أَيُّهَا الْمُجْرِمُونَ","But He will say: Stand apart from the believers today, O wicked ones!","أمر الله للمجرمين بالتميز عن المؤمنين."),
    (36,60,"أَلَمْ أَعْهَدْ إِلَيْكُمْ يَا بَنِي آدَمَ أَن لَّا تَعْبُدُوا الشَّيْطَانَ ۖ إِنَّهُ لَكُمْ عَدُوٌّ مُّبِينٌ","Did I not command you, O children of Adam, not to worship Satan, for he is truly your sworn enemy?","تذكير الله لبني آدم بعهده ألا يعبدوا الشيطان."),
    (36,61,"وَأَنِ اعْبُدُونِي هَٰذَا صِرَاطٌ مُّسْتَقِيمٌ","and that you must worship Me alone? This is the Straight Path.","أمر الله بعبادته وحده وأنها هي الطريق المستقيم."),
    (36,62,"وَلَقَدْ أَضَلَّ مِنكُمْ جِبِلًّا كَثِيرًا ۖ أَفَلَمْ تَكُونُوا تَعْقِلُونَ","Yet he has already led so many of you astray. Did you not have any sense?","تذكير بإضلال الشيطان لكثير من الناس."),
    (36,63,"هَٰذِهِ جَهَنَّمُ الَّتِي كُنتُمْ تُوعَدُونَ","This is the Hell you were promised.","تعريرهم على جهنم التي كان الرسل يوعدونهم بها."),
    (36,64,"اصْلَوْهَا الْيَوْمَ بِمَا كُنتُمْ تَكْفُرُونَ","Burn in it today, because you persistently denied the truth.","أمرهم بدخول النار جزاء كفرهم."),
    (36,65,"الْيَوْمَ نَخْتِمُ عَلَىٰ أَفْوَاهِهِمْ وَتُكَلِّمُنَا أَيْدِيهِمْ وَتَشْهَدُ أَرْجُلُهُم بِمَا كَانُوا يَكْسِبُونَ","Today We will seal their mouths, their hands will speak to Us, and their feet will testify to what they used to commit.","في الآخرة تُختم الأفواه وتشهد الجوارح بأعمال أصحابها."),
    (36,66,"وَلَوْ نَشَاءُ لَطَمَسْنَا عَلَىٰ أَعْيُنِهِمْ فَاسْتَبَقُوا الصِّرَاطَ فَأَنَّىٰ يُبْصِرُونَ","If it had been Our Will, We could have easily blinded their eyes, so they would struggle to find their way. How then could they see?","لو شاء الله لطمس على أعينهم فما أبصروا الطريق."),
    (36,67,"وَلَوْ نَشَاءُ لَمَسَخْنَاهُمْ عَلَىٰ مَكَانَتِهِمْ فَمَا اسْتَطَاعُوا مُضِيًّا وَلَا يَرْجِعُونَ","And if it had been Our Will, We could have easily deformed them in place, leaving them unable to walk or return.","قدرة الله على مسخهم في أماكنهم فلا يقدرون على الحركة."),
    (36,68,"وَمَن نُّعَمِّرْهُ نُنَكِّسْهُ فِي الْخَلْقِ ۖ أَفَلَا يَعْقِلُونَ","And whoever We grant long life, We reverse their development. Do they not then understand?","من أطال الله عمره ردّه إلى أرذل العمر ضعيفاً."),
    (36,69,"وَمَا عَلَّمْنَاهُ الشِّعْرَ وَمَا يَنبَغِي لَهُ ۚ إِنْ هُوَ إِلَّا ذِكْرٌ وَقُرْآنٌ مُّبِينٌ","We have not magically taught the Prophet poetry, nor does it suit him. This revelation is simply a reminder and a clear Quran,","تنزيه النبي عن الشعر، فالقرآن ذكر وبيان لا شعر."),
    (36,70,"لِيُنذِرَ مَن كَانَ حَيًّا وَيَحِقَّ الْقَوْلُ عَلَى الْكَافِرِينَ","to warn whoever is truly alive, and for the word of torment to be proven against the disbelievers.","القرآن إنذار لأهل القلوب الحية، وإلزام للحجة على الكافرين."),
    (36,71,"أَلَمْ يَرَوْا أَنَّا خَلَقْنَا لَهُم مِمَّا عَمِلَتْ أَيْدِينَا أَنْعَامًا فَهُمْ لَهَا مَالِكُونَ","Do they not see that We have created for them—among what Our Hands have fashioned—cattle they own?","تذكير بنعمة خلق الأنعام وتسخيرها لهم."),
    (36,72,"وَذَلَّلْنَاهَا لَهُمْ فَمِنْهَا رَكُوبُهُمْ وَمِنْهَا يَأْكُلُونَ","And We have subjected them cattle to them, so some they ride and some they eat.","تسخير الأنعام للركوب والأكل."),
    (36,73,"وَلَهُمْ فِيهَا مَنَافِعُ وَمَشَارِبُ ۖ أَفَلَا يَشْكُرُونَ","And they have other benefits and drinks in them. Will they not then give thanks?","منافع الأنعام وألبانها، أفلا يشكرون المنعم؟"),
    (36,74,"وَاتَّخَذُوا مِن دُونِ اللَّهِ آلِهَةً لَّعَلَّهُمْ يُنصَرُونَ","Yet they have taken gods other than Allah, hoping to receive help from them.","اتخاذهم آلهة من دون الله رجاء نصرها."),
    (36,75,"لَا يَسْتَطِيعُونَ نَصْرَهُمْ وَهُمْ لَهُمْ جُندٌ مُّحْضَرُونَ","They cannot help them, even though their false gods are mobilized as soldiers ready for battle.","عجز الآلهة عن نصرهم مع أنها محضورة معهم."),
    (36,76,"فَلَا يَحْزُنكَ قَوْلُهُمْ ۖ إِنَّا نَعْلَمُ مَا يُسِرُّونَ وَمَا يُعْلِنُونَ","So do not let their words grieve you O Prophet. We certainly know what they conceal and what they reveal.","تعزية للنبي صلى الله عليه وسلم بأقوال قومه."),
    (36,77,"أَوَلَمْ يَرَ الْإِنسَانُ أَنَّا خَلَقْنَاهُ مِن نُّطْفَةٍ فَإِذَا هُوَ خَصِيمٌ مُّبِينٌ","Does man not see that We created him from a drop of fluid, yet he openly challenges Us?","تعجيب من جدال الإنسان مع أن الله خلقه من نطفة."),
    (36,78,"وَضَرَبَ لَنَا مَثَلًا وَنَسِيَ خَلْقَهُ ۖ قَالَ مَن يُحْيِي الْعِظَامَ وَهِيَ رَمِيمٌ","He compares Us to others, forgetting his own origin, saying: Who can give life to bones after they have decayed?","أنكار المنكر للبعث مع نسيانه خلقه من عدم."),
    (36,79,"قُلْ يُحْيِيهَا الَّذِي أَنشَأَهَا أَوَّلَ مَرَّةٍ ۖ وَهُوَ بِكُلِّ خَلْقٍ عَلِيمٌ","Say, O Prophet: He Who created them in the first place will bring them back to life. And He has full knowledge of His entire creation.","الذي أنشأ العظام من العدم قادر على إحيائها بعد رميمها."),
    (36,80,"الَّذِي جَعَلَ لَكُم مِّنَ الشَّجَرِ الْأَخْضَرِ نَارًا فَإِذَا مِنْهُ تُوقِدُونَ","He is the One Who produced fire for you out of the green tree, so see, you kindle from it.","قدرة الله على إخراج النار من الشجر الأخضر."),
    (36,81,"أَوَلَيْسَ الَّذِي خَلَقَ السَّمَاوَاتِ وَالْأَرْضَ بِقَادِرٍ عَلَىٰ أَن يَخْلُقَ مِثْلَهُم ۚ بَلَىٰ وَهُوَ الْخَلَّاقُ الْعَلِيمُ","Could the One Who created the heavens and the earth not easily create their likes? Yes He could! For He is the Master Creator, All-Knowing.","الذي خلق السماوات والأرض قادر على إعادة الخلق."),
    (36,82,"إِنَّمَا أَمْرُهُ إِذَا أَرَادَ شَيْئًا أَن يَقُولَ لَهُ كُن فَيَكُونُ","When He intends something, He simply says to it: Be! And it is.","سهولة تكوين الشيء بأمره كن فيكون."),
    (36,83,"فَسُبْحَانَ الَّذِي بِيَدِهِ مَلَكُوتُ كُلِّ شَيْءٍ وَإِلَيْهِ تُرْجَعُونَ","So glory be to the One in Whose Hands lies the authority over all things, and to Whom you will all be returned.","تنزيه الله المالك لكل شيء، وإليه مرجع العباد."),
]


def escape_value(s):
    """Convert internal straight double quotes to Unicode smart quotes (alternating)."""
    out = []
    is_left = True
    for ch in s:
        if ch == '"':
            out.append('\u201C' if is_left else '\u201D')
            is_left = not is_left
        elif ch == '\\':
            out.append('\\\\')
        else:
            out.append(ch)
    return ''.join(out)


def write_file(path, name, data):
    lines = [
        f"// Surah {data[0][0]} - {len(data)} verses (auto-generated)",
        "import type { VerseText } from \"./verses\";",
        "",
        f"const {name}: VerseText[] = [",
    ]
    for surah, verse, arabic, trans, tafsir in data:
        a = escape_value(arabic)
        t = escape_value(trans)
        f_ = escape_value(tafsir)
        lines.append(f'  {{ surahNumber: {surah}, verseNumber: {verse}, arabic: "{a}", translation: "{t}", tafsir: "{f_}" }},')
    lines.append("];")
    lines.append("")
    lines.append(f"export const {name.upper()}_VERSES = {name};")
    lines.append("")
    with open(path, 'w', encoding='utf-8') as fp:
        fp.write('\n'.join(lines))
    print(f"Wrote {path} ({len(data)} verses)")


base = "/home/z/my-project/src/lib/quran"
write_file(f"{base}/surah-yaseen.ts", "yaseen", YASEEN)
